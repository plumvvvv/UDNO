.. _reference:

Reference
*********

Contents:

.. toctree::
   :maxdepth: 2
   
   legal
   nxmetis
