..  -*- coding: utf-8 -*-

Bibliography
============

.. [Langtangen04] H.P. Langtangen, "Python Scripting for Computational
    Science.", Springer Verlag Series in Computational Science and
    Engineering, 2004.

.. [Martelli03]  A. Martelli, "Python in a Nutshell", O'Reilly Media
   Inc, 2003.
